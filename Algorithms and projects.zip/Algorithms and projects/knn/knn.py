import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

train_file = pd.read_csv('train.txt', sep=",", header=None)
train_values = train_file.values
train_values_len = train_values[:, 0].size

class_1 = []
class_2 = []

for i in range(train_values_len):
    if (train_values[i][2] == 1):
        class_1.extend([train_values[i, 0:2]])
    elif (train_values[i][2] == 2):
        class_2.extend([train_values[i, 0:2]])

class_1 = np.array(class_1)
class_2 = np.array(class_2)

class_1_x = class_1[:, 0]
class_1_y = class_1[:, 1]
class_2_x = class_2[:, 0]
class_2_y = class_2[:, 1]

plt.scatter(class_1_x, class_1_y, label="class_1", color='red', marker='+')
plt.scatter(class_2_x, class_2_y, label="class_2", color='blue', marker='^')

K = int(input("Number of nearest neighbors: "))

test_file = pd.read_csv('test.txt', sep=",", header=None)
test_values = test_file.values
test_values_len = test_values[:, 0].size

predict_class_1 = []
predict_class_2 = []
preString = ""

for x1 in range(test_values_len):
    details = []
    for x2 in range(train_values_len):
        distance = np.sqrt(np.square((test_values[x1][0]) - (train_values[x2][0])) + np.square(
            (test_values[x1][1]) - (train_values[x2][1])))
        details.append([train_values[x1][2], distance])

    details = np.array(details)
    details = details[details[:, 1].argsort()]

    preString += "Test point: " + str(test_values[x1][0]) + "," + str(test_values[x1][1])

    class_1_count = 0
    class_2_count = 0
    for i in range(K):
        if (details[i][0] == 1):
            class_1_count += 1
            preString += "\nDistance " + str(i + 1) + ": " + str(details[i][1]) + "\t\tClass: 1"

        elif (details[i][0] == 2):
            class_2_count += 1
            preString += "\nDistance " + str(i + 1) + ": " + str(details[i][1]) + "\t\tClass: 2"

    if (class_1_count > class_2_count):
        predict_class_1.extend([test_values[x1, 0:2]])
        preString += "\nPredicted class: 1\n\n"
    else:
        predict_class_2.extend([test_values[x1, 0:2]])
        preString += "\nPredicted class: 2\n\n"

file = open("F:\semester 4.2\pattern lab\knn 1\pattern Lab\prediction.txt", "w")
file.write(preString)
file.close()

predict_class_1 = np.array(predict_class_1)
predict_class_2 = np.array(predict_class_2)

predict_class_1_x = predict_class_1[:, 0]
predict_class_1_y = predict_class_1[:, 1]
predict_class_2_x = predict_class_2[:, 0]

predict_class_2_y= predict_class_2[:,1]


plt.scatter(predict_class_1_x, predict_class_1_y, label="predict class 1", color="black", marker="+")
plt.scatter(predict_class_2_x, predict_class_2_y, label="predict class 2", color="yellow", marker="^")

plt.legend()
plt.show()