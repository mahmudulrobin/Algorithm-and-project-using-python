import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

df = pd.read_csv('train.txt', sep=" " ,  header = None, dtype = 'Int64')
arr = df.values
train_len = arr.shape[0]

cls1_x = []
cls1_y = []

cls2_x = []
cls2_y = []

for i in range(0,train_len):
        if arr[i][2] == 1:
                plt.scatter(arr[i][0], arr[i][1], color='green', marker='+')
                cls1_x.append(arr[i][0])
                cls1_y.append(arr[i][1])
        else:
                plt.scatter(arr[i][0], arr[i][1], color='black', marker='*')
                cls2_x.append(arr[i][0])
                cls2_y.append(arr[i][1])


mean_x1 = np.mean(cls1_x)
mean_y1 = np.mean(cls1_y)
mean_x2 = np.mean(cls2_x)
mean_y2 = np.mean(cls2_y)


df = pd.read_csv('test.txt', sep=" " ,  header = None, dtype = 'Int64')
arr = df.values
test_len = arr.shape[0]

true_count = 0

for i in range(0,test_len):
        x = arr[i][0]
        y = arr[i][1]
        g1 = (x*mean_x1 + y*mean_y1) - 0.5*(mean_x1*mean_x1+mean_y1*mean_y1)
        g2 = (x * mean_x2 + y * mean_y2) - 0.5 * (mean_x2 * mean_x2 + mean_y2 * mean_y2)

        if g1>g2:
                if arr[i][2] == 1:
                        true_count = true_count+1
                plt.scatter(x, y, color = 'green', marker = 'd')
        elif g1<g2:
                if arr[i][2] == 2:
                        true_count = true_count + 1
                plt.scatter(x, y, color='black', marker='p')


print("accuracy is : ",100.00*(true_count/test_len),sep = '')

m1 = mean_x1 - mean_x2
m2 = mean_y1 - mean_y2
c = 0.5 * ((mean_x1*mean_x1+mean_y1*mean_y1) - (mean_x2 * mean_x2 + mean_y2 * mean_y2))

x = []
y = []

for i in range(-7,12):
        x.append(i)
        y.append(((-1.00)* (m1*i)+c)/m2)

plt.plot(x,y,color = 'black',marker = '.')
plt.show()