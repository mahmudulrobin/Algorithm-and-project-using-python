
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

panda_train = pd.read_csv('data.txt', sep=" " ,  header = None, dtype = 'float64')
traindata = panda_train.values
size=traindata[:,0].size


c1=np.array([1.0,0.0])
c2=np.array([4.0,7.0])
fig,plot= plt.subplots(1,1)
fig.set_size_inches(8, 6)
for i in range(10):
    classA=[]
    classB=[]
    
    for j in range(size):
        dist1=pow((traindata[j,0]-c1[0]),2)+pow((traindata[j,1]-c1[1]),2)
        dist2=pow((traindata[j,0]-c2[0]),2)+pow((traindata[j,1]-c2[1]),2)
        if dist1<dist2:  
            classA.append(traindata[j,:])
        else:
            classB.append(traindata[j,:])
        
    classA=np.array(classA)
    classB=np.array(classB)
    
    plt.scatter(classA[:,0], classA[:,1], color = 'r', marker = '+')
    plt.scatter(classB[:,0], classB[:,1], color = 'g', marker = '+')
    
    a_x_mean=np.mean(classA[:,0])
    a_y_mean=np.mean(classA[:,1])
    b_x_mean=np.mean(classB[:,0])
    b_y_mean=np.mean(classB[:,1])
    
    if sum(np.array([a_x_mean,a_y_mean]))-sum(c1)==0 and sum(np.array([b_x_mean,b_y_mean]))-sum(c2)==0:
        break;
    
    c1=np.array([a_x_mean,a_y_mean])
    c2=np.array([b_x_mean,b_y_mean])
    
    
    
    
    
    
    