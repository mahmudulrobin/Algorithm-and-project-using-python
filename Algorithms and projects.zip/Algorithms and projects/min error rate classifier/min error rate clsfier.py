#!/usr/bin/env python
# coding: utf-8

# In[10]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def plot_func(x,mu,sgma):
    t2 = -0.5*np.dot((x-mu),(np.dot(np.linalg.inv(sgma),(x-mu))))
    t3 = (1/((2*np.pi)*(np.sqrt(np.linalg.det(sgma)))))*(np.exp(t2))
    return t3

my_data=pd.read_csv('test.txt',sep=',', header=None, dtype='double').values
mu1 = np.array([0.0,0.0])
sgma1 = np.array([[0.25, 0.3],[0.3, 1.0]])
mu2 = np.array([2.0,2.0])
sgma2 = np.array([[0.5, 0.0],[0.0, 0.5]])

fig = plt.figure()
ax = Axes3D(fig)

for i in range(len(my_data)):
    gx1 = plot_func(my_data[i],mu1,sgma1)
    gx2 = plot_func(my_data[i],mu2,sgma2)
    
    if(gx1>gx2):
        ax.scatter(my_data[i][0], my_data[i][1], label='class 1', color='red', marker='^')
    else:
        ax.scatter(my_data[i][0], my_data[i][1], label='class 2', color='black', marker='*')

x = np.linspace(-6, 6, 200)
y = np.linspace(-6, 6, 200)
X, Y = np.meshgrid(x, y)
Z = np.zeros_like(X)
Decision = np.zeros_like(X)
for n in range(200):
    for m in range(200):
        k = np.array([x[n],y[m]])
        z1 = plot_func(k,mu1,sgma1)
        z2 = plot_func(k,mu2,sgma2)
        Decision[m][n] = z1 - z2
        if(z1>z2):
            Z[m][n] = z1
        else:
            Z[m][n] = z2

ax.plot_surface(X, Y, Z, cmap='viridis',alpha = 0.6)
ax.contour3D(X, Y, Z, zdir='z', offset=-0.2, cmap='viridis')
ax.contour3D(X, Y, Decision, zdir='z', offset=-0.2, cmap='viridis')
ax.set_zlim(-0.2,0.4)
ax.set_zticks(np.linspace(0,0.4,6))
ax.view_init(40, 240)
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Probability density')

fig.show()


# In[ ]:




